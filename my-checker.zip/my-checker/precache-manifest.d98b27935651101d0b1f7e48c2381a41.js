self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b3de142fc4ed3afd683aecbfde53c4f6",
    "url": "/128.png"
  },
  {
    "revision": "45cff23898e01584397e97f4fbd5d380",
    "url": "/64.png"
  },
  {
    "revision": "06176c10eb80494c228fa50ae9f7a242",
    "url": "/background.js"
  },
  {
    "revision": "9847f9d70dea9b99f7996a8342285083",
    "url": "/content.js"
  },
  {
    "revision": "a2326bf35650a00f4cd28f447a67f1b2",
    "url": "/index.html"
  },
  {
    "revision": "c3c046610fef635315e0c4e499f83700",
    "url": "/manifest.json"
  },
  {
    "revision": "ef8a02db437c74f2ecb0d88becc4b9d4",
    "url": "/popup.html"
  },
  {
    "revision": "fa1ded1ed7c11438a9b0385b1e112850",
    "url": "/robots.txt"
  },
  {
    "revision": "a390fee90aef07aadf22",
    "url": "/static/css/index.834c56f7.5ecd60fb.chunk.css"
  },
  {
    "revision": "5f77689bd2d45a98a521",
    "url": "/static/css/main.7f904051.chunk.css"
  },
  {
    "revision": "cf02aed28bc612ad3451",
    "url": "/static/js/0.66bae0f2.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/0.66bae0f2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3f22fae42bbc1357eafe",
    "url": "/static/js/5.151ee11e.chunk.js"
  },
  {
    "revision": "5735008847451525374b1f222e4ab316",
    "url": "/static/js/5.151ee11e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a390fee90aef07aadf22",
    "url": "/static/js/index.834c56f7.7742c7be.chunk.js"
  },
  {
    "revision": "5f77689bd2d45a98a521",
    "url": "/static/js/main.ebb0020a.chunk.js"
  },
  {
    "revision": "36f1dda5bdf560e409b5",
    "url": "/static/js/runtime-index.834c56f7.1f4123a0.js"
  },
  {
    "revision": "0747d69bd3cd51c8b477",
    "url": "/static/js/runtime-main.da2558e8.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);